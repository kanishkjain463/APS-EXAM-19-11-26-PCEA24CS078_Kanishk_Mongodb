// B4: Ticket Booking - Backup, Restore and Disaster Recovery

// Step 1: Select database
use("ticketDB");

const ticketDB = db.getSiblingDB("ticketDB");

// Step 2: Insert five ticket bookings
ticketDB.bookings.drop();

ticketDB.bookings.insertMany([
    {
        _id: 1,
        passenger: "Anand",
        route: "Chennai-Madurai",
        seats: 2
    },
    {
        _id: 2,
        passenger: "Bhuvana",
        route: "Chennai-Coimbatore",
        seats: 1
    },
    {
        _id: 3,
        passenger: "Chandru",
        route: "Madurai-Trichy",
        seats: 3
    },
    {
        _id: 4,
        passenger: "Divya",
        route: "Salem-Chennai",
        seats: 1
    },
    {
        _id: 5,
        passenger: "Elango",
        route: "Chennai-Trichy",
        seats: 2
    }
]);

print("STEP 1: Original Bookings");
ticketDB.bookings.find().forEach(printjson);

print("Total bookings: " + ticketDB.bookings.countDocuments({}));

// Step 3: Create backup collection
ticketDB.bookings_backup.drop();

ticketDB.bookings_backup.insertMany(
    ticketDB.bookings.find().toArray()
);

print("STEP 2: Backup Created Successfully");

print("Backup count: " +
    ticketDB.bookings_backup.countDocuments({}));

// Step 4: Simulate accidental deletion
ticketDB.bookings.drop();

print("STEP 3: Disaster Simulation");

print("Bookings after deletion: " +
    ticketDB.bookings.countDocuments({}));

// Step 5: Restore bookings from backup
ticketDB.bookings.insertMany(
    ticketDB.bookings_backup.find().toArray()
);

print("STEP 4: Restore Completed Successfully");

// Step 6: Verify restored data
print("STEP 5: Final Restored Bookings");

ticketDB.bookings.find().forEach(printjson);

print("Final booking count: " +
    ticketDB.bookings.countDocuments({}));

// Step 7: Verify backup
print("Backup verification:");

print("Backup documents: " +
    ticketDB.bookings_backup.countDocuments({}));

print("Disaster Recovery Completed Successfully!");