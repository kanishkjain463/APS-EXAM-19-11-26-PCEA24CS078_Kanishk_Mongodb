// ==========================================
// SCENARIO B3: MOVIE CATALOGUE
// Index Order, Explain and Hidden Indexes
// ==========================================

// TASK 1: INSERT MOVIE DOCUMENTS

db.movies.insertMany([
    {
        _id: 1,
        title: "Silent River",
        genre: "Drama",
        rating: 8.4,
        year: 2019,
        cast: ["Asha", "Ravi"]
    },
    {
        _id: 2,
        title: "Rapid Chase",
        genre: "Action",
        rating: 7.2,
        year: 2020,
        cast: ["Vikram", "Asha"]
    },
    {
        _id: 3,
        title: "Lost Letters",
        genre: "Drama",
        rating: 7.1,
        year: 2018,
        cast: ["Meera", "Ravi"]
    },
    {
        _id: 4,
        title: "Iron Gate",
        genre: "Action",
        rating: 8.1,
        year: 2021,
        cast: ["Vikram", "Karan"]
    },
    {
        _id: 5,
        title: "Morning Song",
        genre: "Drama",
        rating: 8.8,
        year: 2022,
        cast: ["Meera", "Asha"]
    },
    {
        _id: 6,
        title: "Laugh Lane",
        genre: "Comedy",
        rating: 6.9,
        year: 2017,
        cast: ["Karan", "Meera"]
    },
    {
        _id: 7,
        title: "Night Heist",
        genre: "Action",
        rating: 6.5,
        year: 2019,
        cast: ["Vikram", "Ravi"]
    },
    {
        _id: 8,
        title: "Paper Boats",
        genre: "Drama",
        rating: 7.9,
        year: 2021,
        cast: ["Asha", "Karan"]
    }
]);

// Display all movies
db.movies.find();


// TASK 2: EXPLAIN WITHOUT INDEX

db.movies.find({
    genre: "Drama",
    rating: { $gte: 8 }
}).explain("executionStats");


// TASK 3: CREATE COMPOUND INDEX IN RIGHT ORDER

db.movies.createIndex(
    { genre: 1, rating: -1 }
);

// Check index
db.movies.getIndexes();

// Execute query with correct index
db.movies.find({
    genre: "Drama",
    rating: { $gte: 8 }
}).explain("executionStats");


// TASK 4: CREATE POORLY ORDERED INDEX

db.movies.createIndex(
    { rating: 1, genre: 1 }
);

// Force poorly ordered index
db.movies.find({
    genre: "Drama",
    rating: { $gte: 8 }
}).hint("rating_1_genre_1").explain("executionStats");

// Force correctly ordered index
db.movies.find({
    genre: "Drama",
    rating: { $gte: 8 }
}).hint("genre_1_rating_-1").explain("executionStats");


// TASK 5: DROP POORLY ORDERED INDEX

db.movies.dropIndex("rating_1_genre_1");

// Display remaining indexes
db.movies.getIndexes();


// TASK 6: MULTIKEY INDEX ON CAST

db.movies.createIndex(
    { cast: 1 }
);

// Find movies in which Asha acted
db.movies.find({
    cast: "Asha"
});

// Explain multikey index
db.movies.find({
    cast: "Asha"
}).explain("executionStats");


// TASK 7: HIDE COMPOUND INDEX

db.movies.hideIndex("genre_1_rating_-1");

// Run query after hiding index
db.movies.find({
    genre: "Drama",
    rating: { $gte: 8 }
}).explain("executionStats");


// TASK 8: UNHIDE COMPOUND INDEX

db.movies.unhideIndex("genre_1_rating_-1");

// Verify index
db.movies.getIndexes();


// TASK 9: CREATE SAME INDEX WITH CUSTOM NAME

// Expected IndexOptionsConflict error
try {
    db.movies.createIndex(
        { genre: 1, rating: -1 },
        { name: "movie_genre_rating" }
    );
} catch (error) {
    print("Expected index creation error: " + error);
}


// TASK 10: LIST ALL INDEXES

db.movies.getIndexes();

// ==========================================
// END OF SCENARIO B3
// ==========================================